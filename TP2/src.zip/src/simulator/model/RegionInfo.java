package simulator.model;

public interface RegionInfo extends JSONable {  
	// for now it is empty, later we will make it implement the interface  
	// Iterable<AnimalInfo>  
}
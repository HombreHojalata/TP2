package simulator.model;

public interface FoodSupplier {
	public double getFood(AnimalInfo a, double dt);
}

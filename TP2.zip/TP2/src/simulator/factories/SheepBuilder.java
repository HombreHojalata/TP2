package simulator.factories;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Utils;
import simulator.misc.Vector2D;
import simulator.model.Animal;
import simulator.model.SelectionStrategy;
import simulator.model.Sheep;

public class SheepBuilder extends Builder<Animal> {
	private Factory<SelectionStrategy> stratFactory;

	public SheepBuilder(Factory<SelectionStrategy> stratFactory) {
		super("sheep", "Builder for Sheep");
		this.stratFactory = stratFactory;
	}

	@Override
	protected Animal createInstance(JSONObject data) {
		if (data == null)
			throw new IllegalArgumentException("Data cannot be null");
		SelectionStrategy mateStrategy = stratFactory.createInstance(new JSONObject().put("type", "first"));
		SelectionStrategy dangerStrategy = stratFactory.createInstance(new JSONObject().put("type", "first"));
		Vector2D pos = null;

		if (data.has("mate_strategy"))
			mateStrategy = stratFactory.createInstance(data.getJSONObject("mate_strategy"));
		if (data.has("danger_strategy"))
			dangerStrategy = stratFactory.createInstance(data.getJSONObject("danger_strategy"));
		if (data.has("pos")) {
			JSONObject ps = data.getJSONObject("pos");
			JSONArray x_range = (JSONArray) ps.getJSONArray("x_range");
			JSONArray y_range = (JSONArray) ps.getJSONArray("y_range");
			double x = x_range.getDouble(0) + (x_range.getDouble(1) - x_range.getDouble(0)) * Utils.RAND.nextDouble();
			double y = y_range.getDouble(0) + (y_range.getDouble(1) - y_range.getDouble(0)) * Utils.RAND.nextDouble();
			pos = new Vector2D(x, y);
		}
		return new Sheep(mateStrategy, dangerStrategy, pos);
	}

	@Override
	protected void fillInData(JSONObject o) {
	}
}

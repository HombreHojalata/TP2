package simulator.factories;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Utils;
import simulator.misc.Vector2D;
import simulator.model.Animal;
import simulator.model.SelectionStrategy;
import simulator.model.Wolf;

public class WolfBuilder extends Builder<Animal> {
	private Factory<SelectionStrategy> stratFactory;

	public WolfBuilder(Factory<SelectionStrategy> stratFactory) {
		super("wolf", "Builder for Wolf");
		this.stratFactory = stratFactory;
	}

	@Override
	protected Animal createInstance(JSONObject data) {
		if (data == null)
			throw new IllegalArgumentException("Data cannot be null");
		SelectionStrategy mateStrategy = stratFactory.createInstance(new JSONObject().put("type", "first"));
		SelectionStrategy huntingStrategy = stratFactory.createInstance(new JSONObject().put("type", "first"));
		Vector2D pos = null;

		if (data.has("mate_strategy"))
			mateStrategy = stratFactory.createInstance(data.getJSONObject("mate_strategy"));
		if (data.has("hunting_strategy"))
			huntingStrategy = stratFactory.createInstance(data.getJSONObject("hunting_strategy"));
		if (data.has("pos")) {
			JSONObject ps = data.getJSONObject("pos");
			JSONArray x_range = (JSONArray) ps.getJSONArray("x_range");
			JSONArray y_range = (JSONArray) ps.getJSONArray("y_range");
			double x = x_range.getDouble(0) + (x_range.getDouble(1) - x_range.getDouble(0)) * Utils.RAND.nextDouble();
			double y = y_range.getDouble(0) + (y_range.getDouble(1) - y_range.getDouble(0)) * Utils.RAND.nextDouble();
			pos = new Vector2D(x, y);
		}
		return new Wolf(mateStrategy, huntingStrategy, pos);
	}

	@Override
	protected void fillInData(JSONObject o) {
	}
}

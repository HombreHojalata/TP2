package simulator.view;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.table.AbstractTableModel;
import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;
import simulator.model.State;

@SuppressWarnings("serial")
class SpeciesTableModel extends AbstractTableModel implements EcoSysObserver {
	private String columnnames[];
	private Object data[][];

	SpeciesTableModel(Controller ctrl) {
		columnnames = new String[1 + State.values().length];
		columnnames[0] = "Species";

		for (int i = 0; i < State.values().length; i++) {
			columnnames[i + 1] = State.values()[i].name();
		}
		ctrl.addObserver(this);
	}

	@Override
	public int getRowCount() {
		return data.length;
	}

	@Override
	public int getColumnCount() {
		return columnnames.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return data[rowIndex][columnIndex];
	}

	@Override
	public String getColumnName(int column) {
		return columnnames[column];
	}

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		Map<String, Map<State, Integer>> counts = new HashMap<>();

		for (AnimalInfo a : animals) {
			String species = a.getGeneticCode();
			State state = a.getState();

			counts.putIfAbsent(species, new HashMap<>());

			Map<State, Integer> stateMap = counts.get(species);
			stateMap.put(state, stateMap.getOrDefault(state, 0) + 1);
		}

		data = new Object[counts.size()][columnnames.length];

		int row = 0;
		for (String species : counts.keySet()) {

			data[row][0] = species;

			Map<State, Integer> stateMap = counts.get(species);

			for (int i = 0; i < State.values().length; i++) {
				State s = State.values()[i];
				data[row][i + 1] = stateMap.getOrDefault(s, 0);
			}

			row++;
		}

		fireTableDataChanged();
	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		columnnames = new String[1 + State.values().length];
		columnnames[0] = "Species";

		for (int i = 0; i < State.values().length; i++) {
			columnnames[i + 1] = State.values()[i].name();
		}
		onRegister(time, map, animals);
	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		onRegister(time, map, animals);
	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		this.onRegister(time, map, animals);
	}
}

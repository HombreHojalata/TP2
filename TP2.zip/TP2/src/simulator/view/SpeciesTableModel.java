package simulator.view;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;
import simulator.model.State;

	  @SuppressWarnings("serial")
	  class SpeciesTableModel extends AbstractTableModel implements EcoSysObserver {
		  private String columnnames[];
		  private Object data [] [];

		  SpeciesTableModel(Controller ctrl) {  
			  columnnames = new String[] {"Species" + State.values()};
			  
			  ctrl.addObserver(this);
		  }  
		  // TODO el resto de métodos van aquí …  

		  @Override
		  public int getRowCount() {
			// TODO Auto-generated method stub
			return 0;
		  }

		  @Override
		  public int getColumnCount() {
			// TODO Auto-generated method stub
			return 0;
		  }

		  @Override
		  public Object getValueAt(int rowIndex, int columnIndex) {
			// TODO Auto-generated method stub
			return null;
		  }

		  @Override
		  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
			// TODO Auto-generated method stub
		  }
		  }
			
		  
package simulator.view;

import java.util.List;
import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.Diet;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
class RegionsTableModel extends AbstractTableModel implements EcoSysObserver {
	  private String columnnames[];
	  private Object data [][];
	  RegionsTableModel(Controller ctrl) {  
		  columnnames = new String[3 + Diet.values().length];
		  columnnames[0] = "Row";
		  columnnames[1] = "Col";
		  columnnames[2] = "Desc";
		  for (int i = 0; i < Diet.values().length; i++) {
			  columnnames[i + 3] = Diet.values()[i].toString();
		  }
		ctrl.addObserver(this);  
	  }  


	  @Override
	  public int getRowCount() {
		return data.length;
	  }

	  @Override
	  public int getColumnCount() {
		  return columnnames.length;
	  }

	  @Override
	  public Object getValueAt(int rowIndex, int columnIndex) {
		return data[rowIndex][columnIndex];
	  }
	  
	  @Override
	  public String getColumnName(int column) {
	      return columnnames[column];
	  }

	  @Override
	  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		data = new Object[map.getRows() * map.getCols()][columnnames.length];
		int i = 0;
		for (MapInfo.RegionData region : map) {
				data[i][0] = region.row();
				data[i][1] = region.col();
				data[i][2] = region.r().toString();
				for (int j = 0; j < Diet.values().length; j++) {
				int val = 0;
				for (AnimalInfo a : region.r().getAnimalsInfo())  if(Diet.values()[j].equals(a.getDiet())) val++;
				data[i][j + 3] = val;
				}
				i++;
		}
		fireTableDataChanged();
	  }

	  @Override
	  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		onRegister(time, map, animals);
	  }

	  @Override
	  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		  onRegister(time, map, animals);
	  }

	  @Override
	  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
	      int i = row * map.getCols() + col;

	      MapInfo.RegionData region = new MapInfo.RegionData(row, col, r);
	      updateRow(i, region);

	      fireTableRowsUpdated(i, i);
	  }
	  
	  private void updateRow(int i, MapInfo.RegionData region) {
		    data[i][0] = region.row();
		    data[i][1] = region.col();
		    data[i][2] = region.r().toString();

		    for (int j = 0; j < Diet.values().length; j++) {
		        int val = 0;
		        for (AnimalInfo a : region.r().getAnimalsInfo()) {
		            if (Diet.values()[j].equals(a.getDiet())) val++;
		        }
		        data[i][j + 3] = val; 
		    }
		}

	  @Override
	  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		onRegister(time, map, animals);
	  }
}
package simulator.view;

import simulator.model.AnimalInfo;
import simulator.model.MapInfo;
import simulator.model.State;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


@SuppressWarnings("serial")
public class MapViewer extends AbstractMapViewer {

	// Anchura/altura de la simulación -- se supone que siempre van a ser 
	// iguales al tamaño del componente
	private int width;
	private int height;

	// Número de filas/columnas de la simulación (regiones)
	private int rows;
	private int cols;

	// Anchura/altura de una región
	int rWidth;
	int rHeight;

	// Mostramos sólo animales con este estado. Los posibles valores de currState
	// son null, y los valores de Animal.State.values(). Si es null mostramos todo.
	State currState;

	// En estos atributos guardamos la lista de animales y el tiempo que hemos
	// recibido la última vez para dibujarlos.
	volatile private Collection<AnimalInfo> objs;
	volatile private Double time;

	// Una clase auxilar para almacenar información sobre una especie.
	private static class SpeciesInfo {
		private Integer count;
		private Color color;

		SpeciesInfo(Color color) {
			count = 0;
			this.color = color;
		}
	}

	// Un mapa para la información sobre las especies.
	Map<String, SpeciesInfo> kindsInfo = new HashMap<>();

	// El font que usamos para dibujar texto.
	private Font textFont = new Font("Arial", Font.BOLD, 12);

	// Indica si mostramos el texto la ayuda o no.
	private boolean showHelp;

	public MapViewer() {
		initGUI();
	}

	private void initGUI() {

		addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int i = 0;
				switch (e.getKeyChar()) {
				case 'h':
					showHelp = !showHelp;
					repaint();
					break;
				case 's':
					if ( i > State.values().length) {
						i = 0;
						currState = null;
					}
					else {
						if (currState != null) i++;
						currState = State.values()[i];
					}
					repaint();
				default:
				}
			}

		});

		addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {
				// Esto es necesario para capturar las teclas cuando el ratón está sobre este
				// componente.
				requestFocus(); 
			}
		});

		// Por defecto mostramos todos los animales.
		currState = null;

		// Por defecto mostramos el texto de ayuda.
		showHelp = true;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		Graphics2D gr = (Graphics2D) g;
		gr.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		gr.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		// Cambiar el font para dibujar texto.
		g.setFont(textFont);

		// Dibujar fondo blanco.
		gr.setBackground(Color.WHITE);
		gr.clearRect(0, 0, width, height);

		// Dibujar los animales, el tiempo, informacion sobre los especie, etc.
		if (objs != null)
			drawObjects(gr, objs, time);

		if (showHelp) {
			g.drawString("h: toggle help", 10, 20);
			g.drawString("s: show animals of a specific state", 15, 20);
		}
	}

	private boolean visible(AnimalInfo a) {
		return a.getState().equals(currState);
	}

	private void drawObjects(Graphics2D g, Collection<AnimalInfo> animals, Double time) {
		// Dibuja el grid
		g.setColor(Color.LIGHT_GRAY);
		int cellWidth = width / cols;
		int cellHeight = height / rows;

		for (int c = 0; c <= cols; c++) {
		    int x = c * cellWidth;
		    g.drawLine(x, 0, x, height);
		}
		
		for (int r = 0; r <= rows; r++) {
		    int y = r * cellHeight;
		    g.drawLine(0, y, width, y);
		}
		
		
		// Dibujar los animales.
		for (AnimalInfo a : animals) {

			// Si no es visible saltamos la iteración.
			if (!visible(a))
				continue;

			// La información sobre la especie de 'a'.
			SpeciesInfo speciesInfo = kindsInfo.get(a.getGeneticCode());
			if (speciesInfo == null) {
				speciesInfo = new SpeciesInfo(ViewUtils.getColor(a.getGeneticCode()));
			    kindsInfo.put(a.getGeneticCode(), speciesInfo); 
			}	
			speciesInfo.count++;
			g.setColor(speciesInfo.color);
			g.fillRect((int) a.getPosition().getX(), cols, (int) a.getAge()/2 + 2, (int) a.getAge()/2 + 2);
		}
		
		if (currState != null) {
			g.drawString(currState.toString(), 20, 20);
		}
		int aux = 10;
		for (Entry<String, SpeciesInfo> e : kindsInfo.entrySet()) {
		String s = String.format(e.getKey(), e.getValue().count);
		g.drawString(s, aux, 20);
		aux+= 5;
		e.getValue().count = 0;
		}
	}

	// Un método que dibujar un texto con un rectángulo.
	void drawStringWithRect(Graphics2D g, int x, int y, String s) {
		Rectangle2D rect = g.getFontMetrics().getStringBounds(s, g);
		g.drawString(s, x, y);
		g.drawRect(x - 1, y - (int) rect.getHeight(), (int) rect.getWidth() + 1, (int) rect.getHeight() + 5);
	}

	@Override
	public void update(List<AnimalInfo> objs, Double time) {
		this.time = time;
		this.objs = objs;
		repaint();
	}

	@Override
	public void reset(double time, MapInfo map, List<AnimalInfo> animals) {
		this.width = map.getWidth();
		this.height = map.getHeight();
		this.cols = map.getCols();
		this.rows = map.getRows();
		this.rWidth = map.getRegionWidth();
		this.rHeight = map.getRegionHeight();
		// Esto cambia el tamaño del componente, y así cambia el tamaño de la ventana
		// porque en MapWindow llamamos a pack() después de llamar a reset.
		setPreferredSize(new Dimension(map.getWidth(), map.getHeight()));
		update(animals, time);
	}

}

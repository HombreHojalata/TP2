package simulator.view;
import java.awt.BorderLayout;


import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import javax.swing.table.TableModel;



@SuppressWarnings("serial")
public class InfoTable extends JPanel {

	  private String title;  
	  private TableModel tableModel;

	  InfoTable(String title, TableModel tableModel) {  
	    this.title = title;  
	    this.tableModel = tableModel;  
	    initGUI();  
	  }

	  private void initGUI() {  
		 this.setLayout(new BorderLayout());
		 this.setBorder(BorderFactory.createTitledBorder(title));
		 JTable tabla = new JTable(tableModel);
		 JScrollPane s = new JScrollPane(tabla);
		 this.add(s, BorderLayout.CENTER);
	  }  
	}
		  

package simulator.view;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

public class InfoTable extends JPanel {

	  private String title;  
	  private TableModel tableModel;

	  InfoTable(String title, TableModel tableModel) {  
	    this.title = title;  
	    this.tableModel = tableModel;  
	    initGUI();  
	  }

	  private void initGUI() {  
	    // TODO cambiar el layout del panel a BorderLayout()  
	    // TODO añadir un borde con título al JPanel, con el texto this.title
	    // TODO añadir un JTable (con barra de desplazamiento vertical) que use  
	    //      this.tableModel
	  }  
	  class SpeciesTableModel extends AbstractTableModel implements EcoSysObserver {

		  // TODO definir atributos necesarios

		  SpeciesTableModel(Controller ctrl) {  
		    // TODO inicializar estructuras de datos correspondientes  
		    // TODO registrar this como observador  
		  }  
		  // TODO el resto de métodos van aquí …  

		  @Override
		  public int getRowCount() {
			// TODO Auto-generated method stub
			return 0;
		  }

		  @Override
		  public int getColumnCount() {
			// TODO Auto-generated method stub
			return 0;
		  }

		  @Override
		  public Object getValueAt(int rowIndex, int columnIndex) {
			// TODO Auto-generated method stub
			return null;
		  }

		  @Override
		  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
			// TODO Auto-generated method stub
			
		  }
		  
		  class RegionsTableModel extends AbstractTableModel implements EcoSysObserver {

			  // TODO definir atributos necesarios

			  RegionsTableModel(Controller ctrl) {  
			    // TODO inicializar estructuras de datos correspondientes  
			    // TODO registrar this como observador
			  }  
			  // TODO el resto de métodos van aquí…  

			  @Override
			  public int getRowCount() {
				// TODO Auto-generated method stub
				return 0;
			  }

			  @Override
			  public int getColumnCount() {
				// TODO Auto-generated method stub
				return 0;
			  }

			  @Override
			  public Object getValueAt(int rowIndex, int columnIndex) {
				// TODO Auto-generated method stub
				return null;
			  }

			  @Override
			  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
				// TODO Auto-generated method stub
				
			  }

			  @Override
			  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
				// TODO Auto-generated method stub
				
			  }

			  @Override
			  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
				// TODO Auto-generated method stub
				
			  }

			  @Override
			  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
				// TODO Auto-generated method stub
				
			  }

			  @Override
			  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
				// TODO Auto-generated method stub
				
			  }
			}
		}
}

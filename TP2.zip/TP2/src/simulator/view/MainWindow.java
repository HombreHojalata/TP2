package simulator.view;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
public class MainWindow extends JFrame {

  private Controller ctrl;

  public MainWindow(Controller ctrl) {  
    super("[ECOSYSTEM SIMULATOR]");  
    this.ctrl = ctrl;  
    initGUI();  
  }

  private void initGUI() {  
    JPanel mainPanel = new JPanel(new BorderLayout());  
    setContentPane(mainPanel);

    // TODO crear ControlPanel y añadirlo en PAGE_START de mainPanel

    // TODO crear StatusBar y añadirlo en PAGE_END de mainPanel  

    // Definición del panel de tablas (usa un BoxLayout vertical)  
    JPanel contentPanel = new JPanel();  
    contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));  
    mainPanel.add(contentPanel, BorderLayout.CENTER);

    // TODO crear la tabla de especies y añadirla a contentPanel.  
    //      Usa setPreferredSize(new Dimension(500, 250)) para fijar su tamaño

    // TODO crear la tabla de regiones.  
    //      Usa setPreferredSize(new Dimension(500, 250)) para fijar su tamaño

    // TODO llama a ViewUtils.quit(MainWindow.this) en el método windowClosing

    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);  
    pack();  
    setVisible(true);  
   }  
  class ControlPanel extends JPanel {

	  private Controller ctrl;  
	  private ChangeRegionsDialog changeRegionsDialog;

	  private JToolBar toolaBar;  
	  private JFileChooser fc;  
	  private boolean stopped = true; // utilizado en los botones de run/stop  
	  private JButton quitButton;

	  // TODO añade más atributos aquí …

	  ControlPanel(Controller ctrl) {  
	    this.ctrl = ctrl;  
	    initGUI();  
	  }

	  private void initGUI() {  
	    setLayout(new BorderLayout());  
	    toolaBar = new JToolBar();  
	    add(toolaBar, BorderLayout.PAGE_START);

	    // TODO crear los diferentes botones/atributos y añadirlos a la toolBar.
	    //      Todos ellos han de tener su correspondiente tooltip. Puedes utilizar  
	    //      this.toolaBar.addSeparator() para añadir la línea de separación vertical  
	    //      entre las componentes que lo necesiten.  

	    // Quit Button  
	    this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
	    this.toolaBar.addSeparator();  
	    this.quitButton = new JButton();  
	    this.quitButton.setToolTipText("Quit");  
	    this.quitButton.setIcon(new ImageIcon("resources/icons/exit.png"));  
	    this.quitButton.addActionListener((e) -> ViewUtils.quit(this));  
	    this.toolaBar.add(quitButton);

	    // TODO Inicializar this.fc con una instancia de JFileChooser. Para que siempre  
	    // abre en la carpeta de ejemplos puedes usar:  
	    //  
	    //   this.fc.setCurrentDirectory(new File(System.getProperty("user.dir") + "/resources/examples"));
	   
	    // TODO Inicializar this.changeRegionsDialog con instancias del diálogo de cambio   
	    // de regiones   

	  }   
	  // TODO el resto de métodos van aquí…  
	  private void runSim(int n, double dt) {  
		  if (n > 0 && !this.stopped) {  
		    try {  
		          this.ctrl.advance(dt);  
		          SwingUtilities.invokeLater(() -> runSim(n - 1, dt));  
		    } catch (Exception e) {  
		      // TODO llamar a ViewUtils.showErrorMsg con el mensaje de error
		      //      que corresponda  
		      // TODO activar todos los botones
		      this.stopped = true;  
		    }  
		  } else {  
		    // TODO activar todos los botones  
		    this.stopped = true;  
		  }  
		}
	}

class StatusBar extends JPanel implements EcoSysObserver {

	  // TODO Añadir los atributos necesarios.  

	  StatusBar(Controller ctrl) {  
	    initGUI();  
	    // TODO registrar this como observador  
	  }

	  private void initGUI() {  
	    this.setLayout(new FlowLayout(FlowLayout.LEFT));  
	    this.setBorder(BorderFactory.createBevelBorder(1));

	    // TODO Crear varios JLabel para el tiempo, el número de animales, y la
	    //      dimensión y añadirlos al panel. Puedes utilizar el siguiente código
	    //      para añadir un separador vertical:  
	    //
	    //     JSeparator s = new JSeparator(JSeparator.VERTICAL);  
	    //     s.setPreferredSize(new Dimension(10, 20));  
	    //     this.add(s);  
	  }

	  @Override
	  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		// TODO Auto-generated method stub
		
	  }

	  // TODO el resto de métodos van aquí…  
	}
}
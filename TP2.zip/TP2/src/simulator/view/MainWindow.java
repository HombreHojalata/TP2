package simulator.view;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import javax.swing.table.TableModel;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
public class MainWindow extends JFrame {

  private Controller ctrl;
  private static Dimension TableD = new Dimension(500, 250);

  public MainWindow(Controller ctrl) {  
    super("[ECOSYSTEM SIMULATOR]");  
    this.ctrl = ctrl;  
    initGUI();  
  }

  private void initGUI() {  
	  
	 // Definicion de Panel Principal
    JPanel mainPanel = new JPanel(new BorderLayout());  
    setContentPane(mainPanel);
    JPanel ControlPanel = new ControlPanel(ctrl);
    mainPanel.add(ControlPanel, BorderLayout.PAGE_START);
    JPanel StatusBar = new StatusBar(ctrl);
    mainPanel.add(StatusBar, BorderLayout.PAGE_END);

    // Definición del panel de tablas (usa un BoxLayout vertical)  
    JPanel contentPanel = new JPanel();  
    contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));  
    mainPanel.add(contentPanel, BorderLayout.CENTER);
    
    //Tabla de Especies
    TableModel Species = new SpeciesTableModel(ctrl);
    JPanel SpeciesTable = new  InfoTable("Species", Species);
    SpeciesTable.setPreferredSize(TableD);
    contentPanel.add(SpeciesTable);

   //Tabla de Regiones
    TableModel Regions = new RegionsTableModel(ctrl);
    JPanel RegionsTable = new InfoTable("Regions", Regions);
    RegionsTable.setPreferredSize(TableD);
    contentPanel.add(RegionsTable);

    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    addWindowListener(new WindowAdapter() {
        @Override
        public void windowClosing(WindowEvent e) {
            ViewUtils.quit(MainWindow.this);
        }
    });
    pack();  
    setVisible(true);  
    
    // Definicion de ControlPanel
   }  
  class ControlPanel extends JPanel {

	  private Controller ctrl;  
	  private ChangeRegionsDialog changeRegionsDialog;

	  private JToolBar toolaBar;  
	  private JFileChooser fc;  
	  private boolean stopped = true; // utilizado en los botones de run/stop  
	  private JButton quitButton;
	  private JButton fileButton;
	  private JButton mapButton;
	  private JButton regionsButton;
	  private JButton runButton;
	  private JButton stopButton;
	  private JTextField deltaTextField;
	  private JSpinner stepsSpinner;
	  
	  
	  ControlPanel(Controller ctrl) {  
	    this.ctrl = ctrl;  
	    initGUI();  
	  }

	  private void initGUI() {  
	    setLayout(new BorderLayout());  
	    toolaBar = new JToolBar();  
	    add(toolaBar, BorderLayout.PAGE_START);
	    
	    

	    // TODO crear los diferentes botones/atributos y añadirlos a la toolBar.
	    //      Todos ellos han de tener su correspondiente tooltip. Puedes utilizar  
	    //      this.toolaBar.addSeparator() para añadir la línea de separación vertical entre las componentes que lo necesiten.  

	    //File Button
	   this.fileButton = new JButton();
	   this.fileButton.setToolTipText("Load an input file into the simulator");
	   this.fileButton.setIcon(new ImageIcon("resources/icons/open.png"));
	   this.fileButton.addActionListener((e) -> openFile());
	   this.toolaBar.addSeparator();
	   this.toolaBar.add(fileButton);
	   
	   
	   //Map Button
	   this.mapButton = new JButton();
	   this.mapButton.setToolTipText("Map viewer");
	   this.mapButton.setIcon(new ImageIcon("resources/icons/viewer.png"));
	   this.mapButton.addActionListener((e) -> openMap());
	   this.toolaBar.addSeparator();
	   this.toolaBar.add(mapButton);
	   
	   //Regions Button
	   this.regionsButton = new JButton();
	   this.regionsButton.setToolTipText("Change Regions");
	   this.regionsButton.setIcon(new ImageIcon("resources/icons/regions.png"));
	   this.regionsButton.addActionListener((e) -> this.changeRegionsDialog.open(ViewUtils.getWindow(this)));
	   this.toolaBar.addSeparator();
	   this.toolaBar.add(regionsButton);
	   
	   //Run Button
	   this.runButton = new JButton();
	   this.runButton.setToolTipText("Run the simulation");
	   this.runButton.setIcon(new ImageIcon("resources/icons/run.png"));
	   this.runButton.addActionListener((e) -> this.prepareRun());
	   this.toolaBar.addSeparator();
	   this.toolaBar.add(runButton);
	   
	   //Stop Button
	   this.stopButton = new JButton();
	   this.stopButton.setToolTipText("Stop the simulation");
	   this.stopButton.setIcon(new ImageIcon("resources/icons/stop.png"));
	   this.stopButton.addActionListener((e) -> this.stopped = true);
	   this.toolaBar.addSeparator();
	   this.toolaBar.add(stopButton);
	   
	   
	   
	    // Quit Button  
	    this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
	    this.toolaBar.addSeparator();  
	    this.quitButton = new JButton();  
	    this.quitButton.setToolTipText("Quit");  
	    this.quitButton.setIcon(new ImageIcon("resources/icons/exit.png"));  
	    this.quitButton.addActionListener((e) -> ViewUtils.quit(this));  
	    this.toolaBar.add(quitButton);
	    //File Button
	    

	    
	    

	    // TODO Inicializar this.fc con una instancia de JFileChooser. Para que siempre  
	    // abre en la carpeta de ejemplos puedes usar:  
	    this.fc = new JFileChooser();
	    this.fc.setCurrentDirectory(new File(System.getProperty("user.dir") + "/resources/examples"));
	   
	    // TODO Inicializar this.changeRegionsDialog con instancias del diálogo de cambio   
	    // de regiones  
	    this.changeRegionsDialog = new ChangeRegionsDialog(ctrl);

	  }   
	  // TODO el resto de métodos van aquí…  
	  
	  private void openMap() {
		  JDialog map = new JDialog(MainWindow.this, "[MAP VIEWER]", true);
		   map.setContentPane(new MapViewer());
		   map.pack();
		   map.setLocationRelativeTo(MainWindow.this);
		   map.setVisible(true);
	  }
	  
	  private void openFile() {
		  int result = fc.showOpenDialog(MainWindow.this);
	        if (result == JFileChooser.APPROVE_OPTION) {
	            File selectedFile = fc.getSelectedFile();
	            System.out.println(selectedFile.getAbsolutePath());
	        }
	  }
	  private void setButtons(boolean b) {
		  this.fileButton.setEnabled(b);
		  this.mapButton.setEnabled(b);
		  this.quitButton.setEnabled(b);
		  this.stepsSpinner.setEnabled(b);
		  this.deltaTextField.setEnabled(b);
	  }
	  
	  private void prepareRun() {
		  setButtons(false);
		  this.stopped = false;
		  runSim((int) this.stepsSpinner.getValue(), Double.parseDouble(this.deltaTextField.getText()));
	  }
	  private void runSim(int n, double dt) {  
		  if (n > 0 && !this.stopped) {  
		    try {  
		          this.ctrl.advance(dt);  
		          SwingUtilities.invokeLater(() -> runSim(n - 1, dt));  
		    } catch (Exception e) {  
		      ViewUtils.showErrorMsg("ERROR");
		      setButtons(true);
		      this.stopped = true;  
		    }  
		  } else {  
			setButtons(true);
		    this.stopped = true;  
		  }  
		}
	}

class StatusBar extends JPanel implements EcoSysObserver {

	  // TODO Añadir los atributos necesarios.  

	  StatusBar(Controller ctrl) {  
	    initGUI();  
	    // TODO registrar this como observador  
	  }

	  private void initGUI() {  
	    this.setLayout(new FlowLayout(FlowLayout.LEFT));  
	    this.setBorder(BorderFactory.createBevelBorder(1));

	    // TODO Crear varios JLabel para el tiempo, el número de animales, y la
	    //      dimensión y añadirlos al panel. Puedes utilizar el siguiente código
	    //      para añadir un separador vertical:  
	    //
	    //     JSeparator s = new JSeparator(JSeparator.VERTICAL);  
	    //     s.setPreferredSize(new Dimension(10, 20));  
	    //     this.add(s);  
	  }

	  @Override
	  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		// TODO Auto-generated method stub
		
	  }

	  // TODO el resto de métodos van aquí…  
	}
}
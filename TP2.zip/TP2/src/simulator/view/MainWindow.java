package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.table.TableModel;

import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.FileInputStream;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;
import simulator.launcher.Main;

@SuppressWarnings("serial")
public class MainWindow extends JFrame {

	private Controller ctrl;
	private static Dimension TableD = new Dimension(500, 250);

	public MainWindow(Controller ctrl) {
		super("[ECOSYSTEM SIMULATOR]");
		this.ctrl = ctrl;
		initGUI();
	}

	private void initGUI() {

		// Definicion de Panel Principal
		JPanel mainPanel = new JPanel(new BorderLayout());
		setContentPane(mainPanel);
		JPanel ControlPanel = new ControlPanel(ctrl);
		mainPanel.add(ControlPanel, BorderLayout.PAGE_START);
		JPanel StatusBar = new StatusBar(ctrl);
		mainPanel.add(StatusBar, BorderLayout.PAGE_END);

		// Definición del panel de tablas (usa un BoxLayout vertical)
		JPanel contentPanel = new JPanel();
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		mainPanel.add(contentPanel, BorderLayout.CENTER);

		// Tabla de Especies
		TableModel Species = new SpeciesTableModel(ctrl);
		JPanel SpeciesTable = new InfoTable("Species", Species);
		SpeciesTable.setPreferredSize(TableD);
		contentPanel.add(SpeciesTable);

		// Tabla de Regiones
		TableModel Regions = new RegionsTableModel(ctrl);
		JPanel RegionsTable = new InfoTable("Regions", Regions);
		RegionsTable.setPreferredSize(TableD);
		contentPanel.add(RegionsTable);

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				ViewUtils.quit(MainWindow.this);
			}
		});
		pack();
		setVisible(true);

		// Definicion de ControlPanel
	}

	class ControlPanel extends JPanel {

		private Controller ctrl;
		private ChangeRegionsDialog changeRegionsDialog;
		private JToolBar toolaBar;
		private JFileChooser fc;
		private boolean stopped = true; // utilizado en los botones de run/stop
		private JButton quitButton;
		private JButton fileButton;
		private JButton mapButton;
		private JButton regionsButton;
		private JButton runButton;
		private JButton stopButton;
		private JTextField deltaTextField;
		private JSpinner stepsSpinner;

		ControlPanel(Controller ctrl) {
			this.ctrl = ctrl;
			initGUI();
		}

		private void initGUI() {
			setLayout(new BorderLayout());
			toolaBar = new JToolBar();

			this.fc = new JFileChooser();
			this.fc.setCurrentDirectory(new File(System.getProperty("user.dir") + "/resources/examples"));
			// TODO: Filtro de JSON
			
			this.changeRegionsDialog = new ChangeRegionsDialog(ctrl);

			// File Button
			this.fileButton = new JButton();
			this.fileButton.setToolTipText("Load an input file into the simulator");
			this.fileButton.setIcon(new ImageIcon("resources/icons/open.png"));
			this.fileButton.addActionListener((e) -> openFile());
			this.toolaBar.addSeparator();
			this.toolaBar.add(fileButton);

			// Map Button
			this.mapButton = new JButton();
			this.mapButton.setToolTipText("Map viewer");
			this.mapButton.setIcon(new ImageIcon("resources/icons/viewer.png"));
			this.mapButton.addActionListener((e) -> openMap());
			this.toolaBar.addSeparator();
			this.toolaBar.add(mapButton);

			// Regions Button
			this.regionsButton = new JButton();
			this.regionsButton.setToolTipText("Change Regions");
			this.regionsButton.setIcon(new ImageIcon("resources/icons/regions.png"));
			this.regionsButton.addActionListener((e) -> this.changeRegionsDialog.open(ViewUtils.getWindow(this)));

			this.toolaBar.addSeparator();
			this.toolaBar.add(regionsButton);

			// Run Button
			this.runButton = new JButton();
			this.runButton.setToolTipText("Run the simulation");
			this.runButton.setIcon(new ImageIcon("resources/icons/run.png"));
			this.runButton.addActionListener((e) -> this.prepareRun());
			this.toolaBar.addSeparator();
			this.toolaBar.add(runButton);

			// Stop Button
			this.stopButton = new JButton();
			this.stopButton.setToolTipText("Stop the simulation");
			this.stopButton.setIcon(new ImageIcon("resources/icons/stop.png"));
			this.stopButton.addActionListener((e) -> this.stopped = true);
			this.toolaBar.addSeparator();
			this.toolaBar.add(stopButton);
			// Steps Spinner

			this.toolaBar.add(new JLabel("Steps:"));
			this.stepsSpinner = new JSpinner(new SpinnerNumberModel(10000, 0, 10000, 100));
			this.toolaBar.addSeparator();
			this.toolaBar.add(stepsSpinner);
			// Delta TextField
			this.toolaBar.add(new JLabel("Delta-Time:"));
			this.deltaTextField = new JTextField(String.valueOf(Main.dt), 5);
			this.toolaBar.addSeparator();
			this.toolaBar.add(deltaTextField);

			// Quit Button
			this.toolaBar.add(Box.createGlue()); // this aligns the button to the right
			this.toolaBar.addSeparator();
			this.quitButton = new JButton();
			this.quitButton.setToolTipText("Quit");
			this.quitButton.setIcon(new ImageIcon("resources/icons/exit.png"));
			this.quitButton.addActionListener((e) -> ViewUtils.quit(this));
			this.toolaBar.add(quitButton);

			add(toolaBar, BorderLayout.PAGE_START);

		}

		private void openMap() {
			new MapWindow(MainWindow.this, ctrl);
		}

		private void openFile() {
			int result = fc.showOpenDialog(MainWindow.this);
			if (result == JFileChooser.APPROVE_OPTION) {
				try {
					File selectedFile = fc.getSelectedFile();
					JSONObject json = new JSONObject(new JSONTokener(new java.io.FileInputStream(selectedFile)));

					int cols = json.has("cols") ? json.getInt("cols") : 20;
					int rows = json.has("rows") ? json.getInt("rows") : 15;
					int width = json.has("width") ? json.getInt("width") : 800;
					int height = json.has("height") ? json.getInt("height") : 600;

					this.ctrl.reset(cols, rows, width, height);
					this.ctrl.loadData(json);
				} catch (Exception e) {
					ViewUtils.showErrorMsg("Error al cargar el archivo: " + e.getMessage());
				}
			}
		}

		private void setButtons(boolean b) {
			this.fileButton.setEnabled(b);
			this.mapButton.setEnabled(b);
			this.quitButton.setEnabled(b);
			this.stepsSpinner.setEnabled(b);
			this.deltaTextField.setEnabled(b);
		}

		private void prepareRun() {
			setButtons(false);
			this.stopped = false;
			runSim((int) this.stepsSpinner.getValue(), Double.parseDouble(this.deltaTextField.getText()));
		}

		private void runSim(int n, double dt) {
			if (n > 0 && !this.stopped) {
				try {
					this.ctrl.advance(dt);
					Thread.sleep(20); // Para que no vya tan rápido (FUNCIONA)
					SwingUtilities.invokeLater(() -> runSim(n - 1, dt));
				} catch (Exception e) {
					ViewUtils.showErrorMsg("Error durante la simulación: " + e.getMessage());
					setButtons(true);
					this.stopped = true;
				}
			} else {
				setButtons(true);
				this.stopped = true;
			}
		}
	}

	class StatusBar extends JPanel implements EcoSysObserver {

		private JLabel TimeLabel;
		private JLabel AnimalsLabel;
		private JLabel DimensionLabel;
		private double time;
		private int numAnimals;
		private String dim;

		StatusBar(Controller ctrl) {
			initGUI();
			ctrl.addObserver(this);
		}

		private void initGUI() {
			this.setLayout(new FlowLayout(FlowLayout.LEFT));
			this.setBorder(BorderFactory.createBevelBorder(1));

			// Tiempo Label
			String timeFormated = String.format("%.3f", time);
			this.TimeLabel = new JLabel("Time: " + timeFormated);
			this.add(TimeLabel);

			JSeparator s = new JSeparator(JSeparator.VERTICAL);
			s.setPreferredSize(new Dimension(10, 20));
			this.add(s);

			// Animals Label
			this.AnimalsLabel = new JLabel("Total Animals: " + numAnimals);
			this.add(AnimalsLabel);
			JSeparator s2 = s;
			this.add(s2);

			// Dimension Label
			this.DimensionLabel = new JLabel("Dimension: " + dim);
			this.add(DimensionLabel);
		}

		@Override
		public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
			this.time = time;
			numAnimals = animals.size();
			dim = map.getWidth() + "x" + map.getHeight() + " " + map.getRows() + "x" + map.getCols();
			ChangeAllLabel();
		}

		@Override
		public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
			this.time = time;
			numAnimals = animals.size();
			dim = map.getWidth() + "x" + map.getHeight() + " " + map.getRows() + "x" + map.getCols();
			ChangeAllLabel();
		}

		@Override
		public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
			numAnimals++;
			this.time = time;
			ChangeAllLabel();
		}

		@Override
		public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		}

		@Override
		public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
			this.time = time;
			numAnimals = animals.size();
			ChangeAllLabel();
		}

		private void ChangeAllLabel() {
			this.TimeLabel.setText("Time:" + time);
			this.AnimalsLabel.setText("Total Animals: " + numAnimals);
			this.DimensionLabel.setText("Dimension: " + dim);
		}
	}
}

@SuppressWarnings("serial")
class MapWindow extends JFrame implements EcoSysObserver {
	private Controller ctrl;
	private AbstractMapViewer viewer;
	private Frame parent;

	MapWindow(Frame parent, Controller ctrl) {
		super("[MAP VIEWER]");
		this.ctrl = ctrl;
		this.parent = parent;
		intiGUI();
		ctrl.addObserver(this);
	}

	private void intiGUI() {
		JPanel mainPanel = new JPanel(new BorderLayout());
		this.setContentPane(mainPanel);
		this.viewer = new MapViewer();
		mainPanel.add((MapViewer) this.viewer, BorderLayout.CENTER);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				ctrl.removeObserver(MapWindow.this);
			}
		});
		pack();
		if (this.parent != null)
			setLocation(this.parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
					this.parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);
		setResizable(false);
		setVisible(true);
	}

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		SwingUtilities.invokeLater(() -> {
			this.viewer.reset(time, map, animals);
			pack();
		});

	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		onRegister(time, map, animals);
	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {

	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		SwingUtilities.invokeLater(() -> {
			this.viewer.update(animals, time);
		});
	}
}
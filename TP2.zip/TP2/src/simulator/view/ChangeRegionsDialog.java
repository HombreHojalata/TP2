package simulator.view;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;
import simulator.launcher.Main;
import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
public class ChangeRegionsDialog extends JDialog implements EcoSysObserver {

  private DefaultComboBoxModel<String> regionsModel;  
  private DefaultComboBoxModel<String> fromRowModel;  
  private DefaultComboBoxModel<String> toRowModel;  
  private DefaultComboBoxModel<String> fromColModel;  
  private DefaultComboBoxModel<String> toColModel;

  private DefaultTableModel dataTableModel;  
  private Controller ctrl;
  private List<JSONObject> regionsInfo;

  private String[] headers = { "Key", "Value", "Description" };
  private int status;
  ChangeRegionsDialog(Controller ctrl) {  
    super((Frame)null, true);  
    this.ctrl = ctrl;  
    ctrl.addObserver(this);
    initGUI();  
  }

  private void initGUI() {  
    setTitle("Change Regions");  
    JPanel mainPanel = new JPanel();  
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));  
    setContentPane(mainPanel);
    setTitle("Change Regions");
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
    setContentPane(mainPanel);
    JPanel helpPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel helpLabel = new JLabel(
            "<html>Select a region type, the rows/cols interval, and provide values " +
            "for the parameters in the Value column (default values are used for " +
            "parameters with no value).</html>"
        );

    helpPanel.add(helpLabel);

    JPanel tablePanel = new JPanel(new BorderLayout());

    JTable table = new JTable(dataTableModel); 
    JScrollPane scroll = new JScrollPane(table);

    tablePanel.add(scroll, BorderLayout.CENTER);

    JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    // Region type
    controlsPanel.add(new JLabel("Region type:"));
    JComboBox<String> regionType = new JComboBox<>(new String[]{"default", "dynamic"});
    controlsPanel.add(regionType);
    // Row from/to
    controlsPanel.add(new JLabel("Row from/to:"));
    JSpinner rowFrom = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
    JSpinner rowTo = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
    controlsPanel.add(rowFrom);
    controlsPanel.add(rowTo);
     // Column from/to
    controlsPanel.add(new JLabel("Column from/to:"));
    JSpinner colFrom = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
    JSpinner colTo = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
    controlsPanel.add(colFrom);
    controlsPanel.add(colTo);

    JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

    JButton cancelBtn = new JButton("Cancel");
    JButton okBtn = new JButton("OK");
    cancelBtn.addActionListener(e -> {
    	this.status = 0;
        setVisible(false);
    });
    
    okBtn.addActionListener(e -> {
    	this.okButttonAction();
    });

    buttonsPanel.add(cancelBtn);
    buttonsPanel.add(okBtn);        
    setLocationRelativeTo(null);
     
    this.regionsInfo = Main.regionFactory.getInfo();

    // this.dataTableModel es un modelo de tabla que incluye todos los parámetros de  
    // la region
    this.dataTableModel = new DefaultTableModel() {  
      @Override  
      public boolean isCellEditable(int row, int column) {
    	  return column == 1;
      }  
    };  
    this.dataTableModel.setColumnIdentifiers(this.headers);
    JTable dataTable = new JTable(dataTableModel);
    mainPanel.add(dataTable);

    // this.regionsModel es un modelo de combobox que incluye los tipos de regiones
    this.regionsModel = new DefaultComboBoxModel<>();
    for (JSONObject o : regionsInfo) {
        String desc;

        if (o.has("desc"))
            desc = o.getString("desc");
        else
            desc = o.getString("type");

        regionsModel.addElement(desc);
    }
    JComboBox<String> regionsCB = new JComboBox<>(regionsModel);
    controlsPanel.add(regionsCB); 
    JComboBox<String> fromRowCB = new JComboBox<>(fromRowModel);
    JComboBox<String> toRowCB   = new JComboBox<>(toRowModel);
    JComboBox<String> fromColCB = new JComboBox<>(fromColModel);
    JComboBox<String> toColCB   = new JComboBox<>(toColModel);
    regionsCB.addActionListener(e -> {
        int i = regionsCB.getSelectedIndex();

        JSONObject info = regionsInfo.get(i);
        JSONObject data = info.getJSONObject("data");

     
        dataTableModel.setRowCount(0);

        for (String key : data.keySet()) {
            String desc = data.getString(key);

            dataTableModel.addRow(new Object[] {
                key,       
                "",      
                desc        
            });
        }
    });

    controlsPanel.add(new JLabel("Row from/to:"));
    controlsPanel.add(fromRowCB);
    controlsPanel.add(toRowCB);

    controlsPanel.add(new JLabel("Column from/to:"));
    controlsPanel.add(fromColCB);
    controlsPanel.add(toColCB);

    
    mainPanel.add(helpPanel);
    mainPanel.add(tablePanel);
    mainPanel.add(controlsPanel);
    mainPanel.add(buttonsPanel);
    pack();
 
    setPreferredSize(new Dimension(700, 400)); // puedes usar otro tamaño  
    pack();  
    setResizable(false);  
    setVisible(false);  
  }

  public void open(Frame parent) {
    setLocation(
    parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
    parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);
    pack();  
    setVisible(true);  
  }

  @Override
  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
	  fromRowModel.removeAllElements();
	    toRowModel.removeAllElements();
	    fromColModel.removeAllElements();
	    toColModel.removeAllElements();

	    for (int i = 1; i <= map.getRows(); i++) {
	        fromRowModel.addElement(String.valueOf(i));
	        toRowModel.addElement(String.valueOf(i));
	    }

	    for (int j = 1; j <= map.getCols(); j++) {
	        fromColModel.addElement(String.valueOf(j));
	        toColModel.addElement(String.valueOf(j));
	    }
	
  }

  @Override
  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
	onRegister(time,map,animals);
  }

  @Override
  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
  }

  @Override
  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
  }

  @Override
  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
  }

  private void okButttonAction() {
	    JSONObject regionData = new JSONObject();

	    for (int i = 0; i < dataTableModel.getRowCount(); i++) {

	        String key = (String) dataTableModel.getValueAt(i, 0);
	        String value = (String) dataTableModel.getValueAt(i, 1);

	        if (value != null && !value.isEmpty()) {
	            regionData.put(key, Double.parseDouble(value));
	        }
	    }

	    int idx = (int) regionsModel.getSelectedItem();
	    String regionType = regionsInfo.get(idx).getString("type");
	    
	    int rowFrom = Integer.parseInt((String) fromRowModel.getSelectedItem());
	    int rowTo   = Integer.parseInt((String) toRowModel.getSelectedItem());
	    int colFrom = Integer.parseInt((String) fromColModel.getSelectedItem());
	    int colTo   = Integer.parseInt((String) toColModel.getSelectedItem());

	    JSONObject spec = new JSONObject();
	    spec.put("type", regionType);
	    spec.put("data", regionData);

	    JSONObject region = new JSONObject();
	    region.put("row", new JSONArray(new int[]{rowFrom, rowTo}));
	    region.put("col", new JSONArray(new int[]{colFrom, colTo}));
	    region.put("spec", spec);

	    JSONArray regionsArray = new JSONArray();
	    regionsArray.put(region);

	    JSONObject result = new JSONObject();
	    result.put("regions", regionsArray);
	    
	    this.ctrl.setRegions(result);
	    this.status = 1;

	    setVisible(false);
	  
  }
  
  public int getStatus() {
	  return status;
  }
  
  public Controller getCtrl() {
	  return ctrl;
  }
}
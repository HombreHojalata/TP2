package simulator.view;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;
import simulator.launcher.Main;
import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
public class ChangeRegionsDialog extends JDialog implements EcoSysObserver {

  private DefaultComboBoxModel<String> regionsModel;  
  private DefaultComboBoxModel<String> fromRowModel;  
  private DefaultComboBoxModel<String> toRowModel;  
  private DefaultComboBoxModel<String> fromColModel;  
  private DefaultComboBoxModel<String> toColModel;

  private DefaultTableModel dataTableModel;  
  private Controller ctrl;
  private List<JSONObject> regionsInfo;

  private String[] headers = { "Key", "Value", "Description" };
  private int status;
  ChangeRegionsDialog(Controller ctrl) {  
    super((Frame)null, true);  
    this.ctrl = ctrl;  
    initGUI();  
    ctrl.addObserver(this);
  }

  private void initGUI() {  
    setTitle("Change Regions");  
    JPanel mainPanel = new JPanel();  
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));  
    setContentPane(mainPanel);
    
    this.headers = new String[]{ "Key", "Value", "Description" };
    this.dataTableModel = new DefaultTableModel() {
	    @Override
	    public boolean isCellEditable(int row, int column) {
	    	return column == 1;
	    }
    };
    this.dataTableModel.setColumnIdentifiers(this.headers);
    
    JPanel helpPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    helpPanel.add(new JLabel(
            "<html>Select a region type, the rows/cols interval, and provide values " +
            "for the parameters in the Value column (default values are used for " +
            "parameters with no value).</html>"
        ));

    JPanel tablePanel = new JPanel(new BorderLayout());
    JTable table = new JTable(dataTableModel); 
    // Tamaños como la demo??
    table.getColumnModel().getColumn(0).setPreferredWidth(50);
    table.getColumnModel().getColumn(1).setPreferredWidth(50);
    table.getColumnModel().getColumn(2).setPreferredWidth(400); 
    JScrollPane scroll = new JScrollPane(table);
    tablePanel.add(scroll, BorderLayout.CENTER);

    JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    
    // Region type
    controlsPanel.add(new JLabel("Region type:"));
    this.regionsInfo = Main.regionFactory.getInfo();
    this.regionsModel = new DefaultComboBoxModel<>();
    for (JSONObject o : regionsInfo) {
    	regionsModel.addElement(o.getString("type"));
    }
    JComboBox<String> regionsCB = new JComboBox<>(regionsModel);
    controlsPanel.add(regionsCB);
    
    regionsCB.addActionListener(e -> {
    	int i = regionsCB.getSelectedIndex();
    	JSONObject data = regionsInfo.get(i).getJSONObject("data");
    	dataTableModel.setRowCount(0);
    	for (String key : data.keySet()) {
    		dataTableModel.addRow(new Object[] { key, "", data.getString(key) });
    	}
    });
    
    // Filas y columnsa
    this.fromRowModel = new DefaultComboBoxModel<>();
    this.toRowModel = new DefaultComboBoxModel<>();
    this.fromColModel = new DefaultComboBoxModel<>();
    this.toColModel = new DefaultComboBoxModel<>();

    controlsPanel.add(new JLabel("Row from/to:"));
    controlsPanel.add(new JComboBox<>(fromRowModel));
    controlsPanel.add(new JComboBox<>(toRowModel));
    controlsPanel.add(new JLabel("Column from/to:"));
    controlsPanel.add(new JComboBox<>(fromColModel));
    controlsPanel.add(new JComboBox<>(toColModel));
    
    // Botones
    JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    JButton cancelBtn = new JButton("Cancel");
    JButton okBtn = new JButton("OK");
    cancelBtn.addActionListener(e -> { this.status = 0; setVisible(false); });
    okBtn.addActionListener(e -> okButttonAction());
    buttonsPanel.add(cancelBtn);
    buttonsPanel.add(okBtn);
    
    // Montar el panel principal
    mainPanel.add(helpPanel);
    mainPanel.add(tablePanel);
    mainPanel.add(controlsPanel);
    mainPanel.add(buttonsPanel);

    //setPreferredSize(new Dimension(700, 400));
    pack();  
    setResizable(false);
  }

  public void open(Frame parent) {
    setLocation(
    parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
    parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);
    pack();  
    setVisible(true);  
  }

  @Override
  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
	  fromRowModel.removeAllElements();
	    toRowModel.removeAllElements();
	    fromColModel.removeAllElements();
	    toColModel.removeAllElements();

	    for (int i = 1; i <= map.getRows(); i++) {
	        fromRowModel.addElement(String.valueOf(i));
	        toRowModel.addElement(String.valueOf(i));
	    }

	    for (int j = 1; j <= map.getCols(); j++) {
	        fromColModel.addElement(String.valueOf(j));
	        toColModel.addElement(String.valueOf(j));
	    }
	
  }

  @Override
  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
	onRegister(time,map,animals);
  }

  @Override
  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
  }

  @Override
  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
  }

  @Override
  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
  }

  private void okButttonAction() {
	    JSONObject regionData = new JSONObject();

	    for (int i = 0; i < dataTableModel.getRowCount(); i++) {

	        String key = (String) dataTableModel.getValueAt(i, 0);
	        String value = (String) dataTableModel.getValueAt(i, 1);

	        if (value != null && !value.isEmpty()) {
	            regionData.put(key, Double.parseDouble(value));
	        }
	    }

	    int idx = regionsModel.getIndexOf(regionsModel.getSelectedItem());
	    String regionType = regionsInfo.get(idx).getString("type");
	    
	    int rowFrom = Integer.parseInt((String) fromRowModel.getSelectedItem()) - 1;
	    int rowTo   = Integer.parseInt((String) toRowModel.getSelectedItem()) - 1;
	    int colFrom = Integer.parseInt((String) fromColModel.getSelectedItem()) - 1;
	    int colTo   = Integer.parseInt((String) toColModel.getSelectedItem()) - 1;

	    JSONObject spec = new JSONObject();
	    spec.put("type", regionType);
	    spec.put("data", regionData);

	    JSONObject region = new JSONObject();
	    region.put("row", new JSONArray(new int[]{rowFrom, rowTo}));
	    region.put("col", new JSONArray(new int[]{colFrom, colTo}));
	    region.put("spec", spec);

	    JSONArray regionsArray = new JSONArray();
	    regionsArray.put(region);

	    JSONObject result = new JSONObject();
	    result.put("regions", regionsArray);
	    
	    this.ctrl.setRegions(result);
	    this.status = 1;

	    setVisible(false);
	  
  }
  
  public int getStatus() {
	  return status;
  }
  
  public Controller getCtrl() {
	  return ctrl;
  }
}
package simulator.launcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.control.Controller;
import simulator.factories.*;
import simulator.model.Animal;
import simulator.model.Region;
import simulator.model.SelectionStrategy;
import simulator.model.Simulator;
import simulator.view.MainWindow;
import simulator.misc.Utils;

public class Main {
	
	private enum ExecMode {
		BATCH("batch", "Batch mode"), GUI("gui", "Graphical User Interface mode");
		
		private String tag;
		private String desc;

		private ExecMode(String modeTag, String modeDesc) {
			tag = modeTag;
			desc = modeDesc;
		}

		@SuppressWarnings("unused")
		public String getTag() {
			return tag;
		}

		@SuppressWarnings("unused")
		public String getDesc() {
			return desc;
		}
	}
	
	public static Factory<Region> regionFactory;
	public static Factory<Animal> animalFactory;

	// default values for some parameters
	//
	private final static Double DEFAULT_TIME = 10.0; // in seconds
	private final static Double DEFAULT_DT = 0.03; 

	// some attributes to stores values corresponding to command-line parameters
	//
	public static Double time = DEFAULT_TIME;
	public static Double dt = DEFAULT_DT;
	private static boolean sv = false;
	private static String inFile;
	private static String outFile;
	private static ExecMode mode = ExecMode.BATCH;
	
	private static Controller ctrl;

	private static void parseArgs(String[] args) {

		// define the valid command line options
		//
		Options cmdLineOptions = buildOptions();

		// parse the command line as provided in args
		//
		CommandLineParser parser = new DefaultParser();
		try {
			CommandLine line = parser.parse(cmdLineOptions, args);
			parseHelpOption(line, cmdLineOptions);
			parseInFileOption(line);
			parseOutFileOption(line);
			parseModeOption(line);
			parseTimeOption(line);
			parseDeltaTimeOption(line);
			parseSimpleViewerOption(line);
			

			// if there are some remaining arguments, then something wrong is
			// provided in the command line!
			//
			String[] remaining = line.getArgs();
			if (remaining.length > 0) {
				String error = "Illegal arguments:";
				for (String o : remaining)
					error += (" " + o);
				throw new ParseException(error);
			}

		} catch (ParseException e) {
			System.err.println(e.getLocalizedMessage());
			System.exit(1);
		}

	}

	private static Options buildOptions() {
		Options cmdLineOptions = new Options();

		// help
		cmdLineOptions.addOption(Option.builder("h").longOpt("help").desc("Print this message.").build());

		// input file
		cmdLineOptions.addOption(Option.builder("i").longOpt("input").hasArg().desc("A configuration file.").build());

		// output file
		cmdLineOptions.addOption(Option.builder("o").longOpt("output").hasArg().desc(" Output file, where output is written.").build());
		
		// Mode file
		cmdLineOptions.addOption(Option.builder("m").longOpt("mode").hasArg().desc(
				"Execution Mode. Possible values: 'batch' (Batch  \n"
				+ "  mode), 'gui' (Graphical User Interface mode).  \n"
				+ "  Default value: 'gui'.").build());
		
		//Time
		cmdLineOptions.addOption(Option.builder("t").longOpt("time").hasArg()
				.desc("A real number representing the total simulation time in seconds. Default value: "
						+ DEFAULT_TIME + ".")
				.build());
		//Delta time
		cmdLineOptions.addOption(Option.builder("dt").longOpt("delta time").hasArg()
				.desc(" A double representing actual time, in  \n"+ "seconds, per simulation step. Default value: 0.03")
				.build());
		//Simple viewer
		cmdLineOptions.addOption(Option.builder("sv").longOpt("simple viewer")
				.desc("Show the viewer window in console mode.").build());

		return cmdLineOptions;
	}

	private static void parseHelpOption(CommandLine line, Options cmdLineOptions) {
		if (line.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp(Main.class.getCanonicalName(), cmdLineOptions, true);
			System.exit(0);
		}
	}

	private static void parseInFileOption(CommandLine line) throws ParseException {
		inFile = line.getOptionValue("i");
		if (mode == ExecMode.BATCH && inFile == null) {
			throw new ParseException("In batch mode an input configuration file is required");
		}
	}

	private static void parseTimeOption(CommandLine line) throws ParseException {
		String t = line.getOptionValue("t", DEFAULT_TIME.toString());
		try {
			time = Double.parseDouble(t);
			assert (time >= 0);
		} catch (Exception e) {
			throw new ParseException("Invalid value for time: " + t);
		}
	}
	
	private static void parseModeOption(CommandLine line) throws ParseException {
		    String t = line.getOptionValue("m", "gui");
		    for (ExecMode m : ExecMode.values()) {
		        if (m.tag.equalsIgnoreCase(t)) {
		            mode = m;
		            return;
		        }
		    }
		    throw new ParseException("Invalid mode: " + t);
		}
	private static void parseDeltaTimeOption(CommandLine line) throws ParseException {
		String t = line.getOptionValue("dt", "0.03");
		try {
			dt = Double.parseDouble(t);
			assert (dt >= 0);
		} catch (Exception e) {
			throw new ParseException("Invalid value for  delta time: " +  t);
		}
	}
	
	private static void parseSimpleViewerOption(CommandLine line) {
		if (line.hasOption("sv")) {
			sv = true;
		}
	}
	
	private static void parseOutFileOption(CommandLine line) throws ParseException {
		outFile = line.getOptionValue("o");	
		if (outFile == null) {
			throw new ParseException("Output file is required");
		}
	}


	private static void initFactories() {
		List<Builder<SelectionStrategy>> selectionStrategyBuilders = new ArrayList<>();  
		selectionStrategyBuilders.add(new SelectFirstBuilder());  
		selectionStrategyBuilders.add(new SelectClosestBuilder());
		selectionStrategyBuilders.add(new SelectYoungestBuilder());
		Factory<SelectionStrategy> selectionStrategyFactory = new BuilderBasedFactory<SelectionStrategy>(selectionStrategyBuilders);
		List<Builder<Animal>> animalBuilders = new ArrayList<>();
		animalBuilders.add(new SheepBuilder(selectionStrategyFactory));
		animalBuilders.add(new WolfBuilder(selectionStrategyFactory));
		animalFactory = new BuilderBasedFactory<Animal>(animalBuilders);
		List<Builder<Region>> regionBuilders = new ArrayList<>();
		regionBuilders.add(new DefaultRegionBuilder());
		regionBuilders.add(new DynamicSupplyRegionBuilder());
		regionFactory = new BuilderBasedFactory<Region>(regionBuilders);
		
	}

	private static JSONObject loadJSONFile(InputStream in) {
		return new JSONObject(new JSONTokener(in));
	}


	private static void startBatchMode() throws Exception {
		InputStream is = new FileInputStream(new File(inFile));
		JSONObject obj = loadJSONFile(is);
		OutputStream out = outFile == null ? System.out : new FileOutputStream(new File(outFile));
		Simulator sim = new Simulator(obj.getInt("cols"), obj.getInt("rows"), obj.getInt("width"), obj.getInt("height"), animalFactory, regionFactory); 
		ctrl = new Controller(sim);
		ctrl.loadData(obj);
		ctrl.run(time, dt, sv, out);
		out.close();
	}

	private static void startGUIMode() throws Exception {
		InputStream is = new FileInputStream(new File(inFile));
		JSONObject obj = loadJSONFile(is);
		Simulator sim = new Simulator(obj.getInt("cols"), obj.getInt("rows"), obj.getInt("width"), obj.getInt("height"), animalFactory, regionFactory); 
		ctrl = new Controller(sim);
		ctrl.loadData(obj);
		SwingUtilities.invokeAndWait(() -> new MainWindow(ctrl));
	}

	private static void start(String[] args) throws Exception {
		initFactories();
		parseArgs(args);
		switch (mode) {
		case BATCH:
			startBatchMode();
			break;
		case GUI:
			startGUIMode();
			break;
		}
	}

	public static void main(String[] args) {
		Utils.RAND.setSeed(2147483647l);
		try {
			start(args);
		} catch (Exception e) {
			System.err.println("Something went wrong ...");
			System.err.println();
			e.printStackTrace();
		}
	}
}